package com.wwyck.wwyck.wwyck

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
