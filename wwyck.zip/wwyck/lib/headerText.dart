import 'package:flutter/material.dart';

class HeaderText extends StatelessWidget{
  HeaderText(
    //This method holds all properties of the text
    this.text
   );


    final String text;
  

     @override
  Widget build(BuildContext context) {
    return Container(
       padding: EdgeInsets.only(left: 20, right: 20,top:100),
      child: Text(text,
                       style: new TextStyle(color: Colors.blueAccent, fontSize: 25.0),),
    );
  }

}